//--------------------------------------------------------------------------------------
// stdafx.cpp
//
// Precompiled header for the TiledTexturePackTool.
//
// Copyright (C) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------

#include "stdafx.h"

