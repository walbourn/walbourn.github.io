//--------------------------------------------------------------------------------------
// File: TexConv.cpp
//
// D3DX10/11 Texture Converer
//
// Copyright (c) Microsoft Corporation. All rights reserved.
//--------------------------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <dxgi.h>
#include <d3d10_1.h>
#include <d3dx10.h>
#include <d3d11.h>
#include <d3dx11.h>

#ifndef SAFE_RELEASE
#define SAFE_RELEASE(p)      { if (p) { (p)->Release(); (p)=NULL; } }
#endif

enum OPTIONS
{
    OPT_WIDTH = 1,
    OPT_HEIGHT,
    OPT_DEPTH,
    OPT_MIPLEVELS,
    OPT_FORMAT,
    OPT_FILTER,
    OPT_MIPFILTER,
    OPT_SRGBI,
    OPT_SRGBO,
    OPT_SRGB,
    OPT_PREFIX,
    OPT_SUFFIX,
    OPT_OUTPUTDIR,
    OPT_FILETYPE,
    OPT_NOLOGO,
    OPT_D3DX10,
    OPT_D3DX11,
};

struct SConversion
{
    WCHAR szSrc [MAX_PATH];
    WCHAR szDest[MAX_PATH];

    SConversion *pNext;
};

struct SValue
{
    LPCWSTR pName;
    DWORD dwValue;
    DWORD dwEx;
};


//////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////


SValue g_pOptions[] = 
{
    { L"w",             OPT_WIDTH     , 0 },
    { L"h",             OPT_HEIGHT    , 0 },
    { L"d",             OPT_DEPTH     , 0 },
    { L"m",             OPT_MIPLEVELS , 0 },
    { L"f",             OPT_FORMAT    , 0 },
    { L"if",            OPT_FILTER    , 0 },
    { L"mf",            OPT_MIPFILTER , 0 },
    { L"srgbi",         OPT_SRGBI     , 0 },
    { L"srgbo",         OPT_SRGBO     , 0 },
    { L"srgb",          OPT_SRGB      , 0 },
    { L"px",            OPT_PREFIX    , 0 },
    { L"sx",            OPT_SUFFIX    , 0 },
    { L"o",             OPT_OUTPUTDIR , 0 },
    { L"ft",            OPT_FILETYPE  , 0 },
    { L"nologo",        OPT_NOLOGO    , 0 },
    { L"10",            OPT_D3DX10    , 0 },
    { L"11",            OPT_D3DX11    , 0 },
    { NULL,             0             , 0 }
};

#define DEFFMT(fmt) { TEXT( # fmt ), DXGI_FORMAT_ ## fmt , 0 }
#define DEFFMTEX(fmt) { TEXT( # fmt ), DXGI_FORMAT_ ## fmt , 1 }

SValue g_pFormats[] = 
{
    // List does not include _TYPELESS or depth/stencil formats

    DEFFMT(R32G32B32A32_FLOAT), 
    DEFFMT(R32G32B32A32_UINT), 
    DEFFMT(R32G32B32A32_SINT), 
    DEFFMT(R32G32B32_FLOAT), 
    DEFFMT(R32G32B32_UINT), 
    DEFFMT(R32G32B32_SINT), 
    DEFFMT(R16G16B16A16_FLOAT), 
    DEFFMT(R16G16B16A16_UNORM), 
    DEFFMT(R16G16B16A16_UINT), 
    DEFFMT(R16G16B16A16_SNORM), 
    DEFFMT(R16G16B16A16_SINT), 
    DEFFMT(R32G32_FLOAT), 
    DEFFMT(R32G32_UINT), 
    DEFFMT(R32G32_SINT), 
    DEFFMT(R10G10B10A2_UNORM), 
    DEFFMT(R10G10B10A2_UINT), 
    DEFFMT(R11G11B10_FLOAT), 
    DEFFMT(R8G8B8A8_UNORM), 
    DEFFMT(R8G8B8A8_UNORM_SRGB), 
    DEFFMT(R8G8B8A8_UINT), 
    DEFFMT(R8G8B8A8_SNORM), 
    DEFFMT(R8G8B8A8_SINT), 
    DEFFMT(R16G16_FLOAT), 
    DEFFMT(R16G16_UNORM), 
    DEFFMT(R16G16_UINT), 
    DEFFMT(R16G16_SNORM), 
    DEFFMT(R16G16_SINT), 
    DEFFMT(R32_FLOAT), 
    DEFFMT(R32_UINT), 
    DEFFMT(R32_SINT), 
    DEFFMT(R8G8_UNORM), 
    DEFFMT(R8G8_UINT), 
    DEFFMT(R8G8_SNORM), 
    DEFFMT(R8G8_SINT), 
    DEFFMT(R16_FLOAT), 
    DEFFMT(R16_UNORM), 
    DEFFMT(R16_UINT), 
    DEFFMT(R16_SNORM), 
    DEFFMT(R16_SINT), 
    DEFFMT(R8_UNORM), 
    DEFFMT(R8_UINT), 
    DEFFMT(R8_SNORM), 
    DEFFMT(R8_SINT), 
    DEFFMT(A8_UNORM), 
    // d3dx doesn't support this DEFFMT(R1_UNORM), 
    DEFFMT(R9G9B9E5_SHAREDEXP), 
    DEFFMT(R8G8_B8G8_UNORM), 
    DEFFMT(G8R8_G8B8_UNORM), 
    DEFFMT(BC1_UNORM), 
    DEFFMT(BC1_UNORM_SRGB), 
    DEFFMT(BC2_UNORM), 
    DEFFMT(BC2_UNORM_SRGB), 
    DEFFMT(BC3_UNORM), 
    DEFFMT(BC3_UNORM_SRGB), 
    DEFFMT(BC4_UNORM), 
    DEFFMT(BC4_SNORM), 
    DEFFMT(BC5_UNORM), 
    DEFFMT(BC5_SNORM),

    // D3D10/11 does not support 16-bit formats (DXGI_FORMAT_B5G6R5_UNORM, DXGI_FORMAT_B5G5R5A1_UNORM)

    // DXGI 1.1 formats
    DEFFMTEX(B8G8R8A8_UNORM),
    DEFFMTEX(B8G8R8X8_UNORM),
    DEFFMTEX(B8G8R8A8_UNORM_SRGB),
    DEFFMTEX(B8G8R8X8_UNORM_SRGB),
    DEFFMTEX(BC6H_UF16),
    DEFFMTEX(BC6H_SF16),
    DEFFMTEX(BC7_UNORM),
    DEFFMTEX(BC7_UNORM_SRGB),

    { NULL, DXGI_FORMAT_UNKNOWN, 0 }
};

// D3DX10_FILTER_ and D3DX11_FILTER_ are identical
SValue g_pFilters[] = 
{
    { L"NONE",           D3DX10_FILTER_NONE                             , 0 },
    { L"POINT",          D3DX10_FILTER_POINT                            , 0 },
    { L"LINEAR",         D3DX10_FILTER_LINEAR                           , 0 },
    { L"TRIANGLE",       D3DX10_FILTER_TRIANGLE                         , 0 },
    { L"BOX",            D3DX10_FILTER_BOX                              , 0 },
    { L"NONE_DITHER",    D3DX10_FILTER_NONE | D3DX10_FILTER_DITHER      , 0 },
    { L"POINT_DITHER",   D3DX10_FILTER_POINT | D3DX10_FILTER_DITHER     , 0 },
    { L"LINEAR_DITHER",  D3DX10_FILTER_LINEAR | D3DX10_FILTER_DITHER    , 0 },
    { L"TRIANGLE_DITHER",D3DX10_FILTER_TRIANGLE | D3DX10_FILTER_DITHER  , 0 },
    { L"BOX_DITHER",     D3DX10_FILTER_BOX  | D3DX10_FILTER_DITHER      , 0 },
    { NULL,              D3DX10_DEFAULT                                 , 0 }
};


// D3DX10_IFF_ and D3DX11_IFF_ are identical
SValue g_pSaveFileTypes[] =     // valid formats to write to
{
    { L"BMP",           D3DX10_IFF_BMP   , 0 },
    { L"JPG",           D3DX10_IFF_JPG   , 0 },
    { L"PNG",           D3DX10_IFF_PNG   , 0 },
    { L"DDS",           D3DX10_IFF_DDS   , 0 },
    { L"TIFF",          D3DX10_IFF_TIFF  , 0 },
    { L"WDP",           D3DX10_IFF_WMP   , 0 },
    { L"HDP",           D3DX10_IFF_WMP   , 0 },
    { NULL,             D3DX10_IFF_DDS   , 0 }
};

SValue g_pFileTypes[] =         // all d3dx formats
{
    { L"BMP",           D3DX10_IFF_BMP   , 0 },
    { L"JPG",           D3DX10_IFF_JPG   , 0 },
    { L"PNG",           D3DX10_IFF_PNG   , 0 },
    { L"DDS",           D3DX10_IFF_DDS   , 0 },
    { L"TIFF",          D3DX10_IFF_TIFF  , 0 },
    { L"GIF",           D3DX10_IFF_GIF   , 0 },
    { L"WDP",           D3DX10_IFF_WMP   , 0 },
    { L"HDP",           D3DX10_IFF_WMP   , 0 },
    { NULL,             D3DX10_IFF_DDS   , 0 }

};


//////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////

// Direct3D 10
typedef HRESULT (WINAPI* PFN_D3DX10_CREATE_DEVICE)(IDXGIAdapter *, D3D10_DRIVER_TYPE, HMODULE, UINT, ID3D10Device **ppDevice);
typedef HRESULT (WINAPI* PFN_D3DX10_GETIMAGEINFOFROMFILEW)(LPCWSTR, ID3DX10ThreadPump*, D3DX10_IMAGE_INFO*, HRESULT* );
typedef HRESULT (WINAPI* PFN_D3DX10_CREATETEXTUREFROMFILEW)(ID3D10Device*, LPCWSTR, D3DX10_IMAGE_LOAD_INFO*, ID3DX10ThreadPump*, ID3D10Resource**, HRESULT* );
typedef HRESULT (WINAPI* PFN_D3DX10_SAVETEXTURETOFILEW)(ID3D10Resource*, D3DX10_IMAGE_FILE_FORMAT, LPCWSTR );

PFN_D3DX10_CREATE_DEVICE g_pD3DX10CreateDevice = NULL;
PFN_D3DX10_GETIMAGEINFOFROMFILEW g_pD3DX10GetImageInfoFromFile = NULL;
PFN_D3DX10_CREATETEXTUREFROMFILEW g_pD3DX10CreateTextureFromFile = NULL;
PFN_D3DX10_SAVETEXTURETOFILEW g_pD3DX10SaveTextureToFile = NULL;

// Direct3D 11
typedef HRESULT (WINAPI* PFN_D3DX11_GETIMAGEINFOFROMFILEW)(LPCWSTR, ID3DX11ThreadPump*, D3DX11_IMAGE_INFO*, HRESULT* );
typedef HRESULT (WINAPI* PFN_D3DX11_CREATETEXTUREFROMFILEW)(ID3D11Device*, LPCWSTR, D3DX11_IMAGE_LOAD_INFO*, ID3DX11ThreadPump*, ID3D11Resource**, HRESULT* );
typedef HRESULT (WINAPI* PFN_D3DX11_SAVETEXTURETOFILEW)(ID3D11DeviceContext*, ID3D11Resource*, D3DX11_IMAGE_FILE_FORMAT, LPCWSTR );

PFN_D3D11_CREATE_DEVICE g_pD3D11CreateDevice = NULL;
PFN_D3DX11_GETIMAGEINFOFROMFILEW g_pD3DX11GetImageInfoFromFile = NULL;
PFN_D3DX11_CREATETEXTUREFROMFILEW g_pD3DX11CreateTextureFromFile = NULL;
PFN_D3DX11_SAVETEXTURETOFILEW g_pD3DX11SaveTextureToFile = NULL;

//////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////


DWORD Lookup(WCHAR *pName, SValue *pValue)
{
    while(pValue->pName)
    {
        if(!_wcsicmp(pName, pValue->pName))
            return pValue->dwValue;

        pValue++;
    }

    return pValue->dwValue;
}

const WCHAR* LookupFileType(D3DX10_IMAGE_FILE_FORMAT format, SValue *pValue)
{
    while(pValue->pName)
    {
        if(format == (D3DX10_IMAGE_FILE_FORMAT)pValue->dwValue)
            return pValue->pName;

        pValue++;
    }

    return NULL;
}


void PrintFormat(DXGI_FORMAT Format)
{
    for(SValue *pFormat = g_pFormats; pFormat->pName; pFormat++)
    {
        if((DXGI_FORMAT) pFormat->dwValue == Format)
        {
            wprintf( pFormat->pName);
            break;
        }
    }
}


void PrintInfo(D3DX10_IMAGE_INFO *pInfo)
{
    wprintf( L" (%ux%u", pInfo->Width, pInfo->Height);

    if(D3D10_RESOURCE_DIMENSION_TEXTURE3D == pInfo->ResourceDimension)
        wprintf( L"x%u", pInfo->Depth);

    if(pInfo->MipLevels > 1)
        wprintf( L",%u", pInfo->MipLevels);

    wprintf( L" ");
    PrintFormat(pInfo->Format);

    switch(pInfo->ResourceDimension)
    {
    case D3D10_RESOURCE_DIMENSION_BUFFER:         wprintf( L" BUFFER"); break;
    case D3D10_RESOURCE_DIMENSION_TEXTURE1D:	    wprintf( L" 1D"); break;
    case D3D10_RESOURCE_DIMENSION_TEXTURE2D:	    
        if( pInfo->ArraySize > 1 )
            wprintf( L" 2DArray"); 
        else
            wprintf( L" 2D"); 
        break;
    case D3D10_RESOURCE_DIMENSION_TEXTURE3D:        wprintf( L" 3D"); break;
    }

    const WCHAR* fileTypeName = LookupFileType(pInfo->ImageFileFormat, g_pFileTypes);
    if (fileTypeName)
        wprintf( L" %s", fileTypeName);
    else
        wprintf( L" UNKNOWN");

    wprintf( L")");
}


void PrintList(UINT cch, SValue *pValue)
{
    while(pValue->pName)
    {
        UINT cchName = wcslen(pValue->pName);
        
        if(cch + cchName + 2>= 80)
        {
            wprintf( L"\n      ");
            cch = 6;
        }

        wprintf( L"%s%s", pValue->pName, pValue->dwEx ? L"* " : L" " );
        cch += cchName + 2;
        pValue++;
    }

    wprintf( L"\n");
}


void PrintLogo()
{
    wprintf( L"Microsoft (R) Direct3D Extended Texture Converter\n");
    wprintf( L"Copyright (C) Microsoft Corp 2011. All rights reserved.\n");
    wprintf( L"\n");
}


void PrintUsage()
{
    PrintLogo();

    wprintf( L"Usage: texconvex <options> <files>\n");
    wprintf( L"\n");
    wprintf( L"   -w <n>              width\n");
    wprintf( L"   -h <n>              height\n");
    wprintf( L"   -d <n>              depth\n");
    wprintf( L"   -m <n>              miplevels\n");
    wprintf( L"   -f <format>         format\n");
    wprintf( L"   -if <filter>        image filter\n");
    wprintf( L"   -mf <filter>        mip filter\n");
    wprintf( L"   -srgb{i|o}          sRGB {input, output}\n");
    wprintf( L"   -px <string>        name prefix\n");
    wprintf( L"   -sx <string>        name suffix\n");
    wprintf( L"   -o <directory>      output directory\n");
    wprintf( L"   -ft <filetype>      file type\n");
    wprintf( L"   -nologo             suppress copyright message\n");
    wprintf( L"   -10 or -11          Force use of D3DX10 vs. D3DX11\n");

    wprintf( L"\n");
    wprintf( L"   <format>: ");
    PrintList(13, g_pFormats);
    wprintf( L"\n      * == DXGI 1.1/Direct3D 11 format\n");

    wprintf( L"\n");
    wprintf( L"   <filter>: ");
    PrintList(13, g_pFilters);

    wprintf( L"\n");
    wprintf( L"   <filetype>: ");
    PrintList(15, g_pSaveFileTypes);
}

HRESULT FindD3DExports( UINT uAPI )
{
    if ( uAPI == 0 || uAPI == 11 )
    {
        HMODULE hd3d11 = LoadLibrary( L"d3d11.dll" );

        if ( hd3d11 != NULL )
        {
            HMODULE hd3dx11 = LoadLibrary( D3DX11_DLL );
            if ( hd3dx11 != NULL )
            {
                g_pD3D11CreateDevice = (PFN_D3D11_CREATE_DEVICE)GetProcAddress( hd3d11, "D3D11CreateDevice" );
                g_pD3DX11GetImageInfoFromFile = (PFN_D3DX11_GETIMAGEINFOFROMFILEW)GetProcAddress( hd3dx11, "D3DX11GetImageInfoFromFileW" );
                g_pD3DX11CreateTextureFromFile = (PFN_D3DX11_CREATETEXTUREFROMFILEW)GetProcAddress( hd3dx11, "D3DX11CreateTextureFromFileW" );
                g_pD3DX11SaveTextureToFile = (PFN_D3DX11_SAVETEXTURETOFILEW)GetProcAddress( hd3dx11, "D3DX11SaveTextureToFileW" );

                if ( g_pD3D11CreateDevice != NULL
                     && g_pD3DX11GetImageInfoFromFile != NULL
                     && g_pD3DX11CreateTextureFromFile != NULL
                     && g_pD3DX11SaveTextureToFile != NULL )
                {
                    return S_OK;
                }
                else if ( uAPI == 11 )
                {
                    wprintf( L"Failed getting exports from D3D11.DLL/" D3DX11_DLL L".\n");
                    return E_FAIL;
                }
            }
            else if ( uAPI == 11 )
            {
                wprintf( L"This application requires " D3DX11_DLL L" which is not installed.\n");
                return E_FAIL;
            }
        }
        else if ( uAPI == 11 )
        {
            wprintf( L"This application requires Direct3D 11 which is not installed on this version of Windows.\n");
            return E_FAIL;
        }
    }

    HMODULE hd3d10 = LoadLibrary( L"d3d10.dll");
    if ( hd3d10 != NULL )
    {
        HMODULE hd3dx10 = LoadLibrary( D3DX10_DLL );
        if ( hd3dx10 != NULL )
        {
            g_pD3DX10CreateDevice = (PFN_D3DX10_CREATE_DEVICE)GetProcAddress( hd3dx10, "D3DX10CreateDevice" );
            g_pD3DX10GetImageInfoFromFile = (PFN_D3DX10_GETIMAGEINFOFROMFILEW)GetProcAddress( hd3dx10, "D3DX10GetImageInfoFromFileW" );
            g_pD3DX10CreateTextureFromFile = (PFN_D3DX10_CREATETEXTUREFROMFILEW)GetProcAddress( hd3dx10, "D3DX10CreateTextureFromFileW" );
            g_pD3DX10SaveTextureToFile = (PFN_D3DX10_SAVETEXTURETOFILEW)GetProcAddress( hd3dx10, "D3DX10SaveTextureToFileW" );

            if ( g_pD3DX10CreateDevice != NULL 
                 && g_pD3DX10GetImageInfoFromFile != NULL
                 && g_pD3DX10CreateTextureFromFile != NULL
                 && g_pD3DX10SaveTextureToFile != NULL )
            {
                return S_OK;
            }
            else
            {
                wprintf( L"Failed getting exports from " D3DX10_DLL L".\n");
                return E_FAIL;
            }
        }
        else
        {
            wprintf( L"This application requires " D3DX10_DLL L" which is not installed.\n");
            return E_FAIL;
        }
    }
    else
    {
        wprintf( L"This application requires Direct3D 10 which is not available on this version of Windows.\n");
        return E_FAIL;
    }
}

HRESULT CreateDevice(ID3D10Device** ppDev)
{
    if ( !g_pD3DX10CreateDevice )
        return E_FAIL;

    HRESULT hr = g_pD3DX10CreateDevice( NULL, D3D10_DRIVER_TYPE_WARP, NULL, 0, ppDev);

    if ( FAILED(hr) )
    {
        // WARP is not present on systems without the DirectX 11 runtime, so we fall back to the
        // old stand-by of the REFERENCE device
        hr = g_pD3DX10CreateDevice( NULL, D3D10_DRIVER_TYPE_REFERENCE, NULL, 0, ppDev);
    }

    return hr;
}

HRESULT CreateDevice( ID3D11Device** ppDev, ID3D11DeviceContext** ppContext )
{
    if ( !g_pD3D11CreateDevice )
        return E_FAIL;

    // WARP doesn't support Feature level 11 for BC6H/BC7 support, so we must use the REFERENCE device
    return g_pD3D11CreateDevice( NULL, D3D_DRIVER_TYPE_REFERENCE, NULL, 0, NULL, 0, 
                                 D3D11_SDK_VERSION, ppDev, NULL, ppContext );
}

int wmain(int argc, wchar_t* argv[])
{
    // Parameters and defaults
    HRESULT hr;
    INT nReturn;

    UINT uWidth = D3DX10_DEFAULT;
    UINT uHeight = D3DX10_DEFAULT; 
    UINT uDepth  = D3DX10_DEFAULT;
    UINT uMipLevels = D3DX10_DEFAULT;
    DXGI_FORMAT Format = DXGI_FORMAT_FROM_FILE;
    DWORD dwFilter = D3DX10_FILTER_TRIANGLE | D3DX10_FILTER_DITHER;
    DWORD dwMipFilter = D3DX10_FILTER_BOX;
    DWORD dwSRGB = 0;
    D3DX10_IMAGE_FILE_FORMAT FileType = D3DX10_IFF_DDS;

    WCHAR szPrefix   [MAX_PATH];
    WCHAR szSuffix   [MAX_PATH];
    WCHAR szOutputDir[MAX_PATH];

    szPrefix[0]    = 0;
    szSuffix[0]    = 0;
    szOutputDir[0] = 0;

    // Initialize COM
    if( FAILED( hr = CoInitializeEx(NULL, COINIT_MULTITHREADED) ) )
    {
        wprintf( L"Failed to initialize COM (%08X)\n", hr);
        return 1;
    }

    // Process command line
    DWORD dwOptions = 0;
    SConversion *pConversion = NULL;
    SConversion **ppConversion = &pConversion;

    UINT uAPI = 0;

    for(INT iArg = 1; iArg < argc; iArg++)
    {
        WCHAR *pArg = argv[iArg];

        if(('-' == pArg[0]) || ('/' == pArg[0]))
        {
            pArg++;
            WCHAR *pValue;

            for(pValue = pArg; *pValue && (':' != *pValue); pValue++);

            if(*pValue)
                *pValue++ = 0;

            DWORD dwOption = Lookup(pArg, g_pOptions);

            if(!dwOption || (dwOptions & (1 << dwOption)))
            {
                PrintUsage();
                return 1;
            }

            dwOptions |= 1 << dwOption;

            if((OPT_NOLOGO != dwOption) && (OPT_SRGB != dwOption) && (OPT_SRGBI != dwOption) && (OPT_SRGBO != dwOption)
               && (OPT_D3DX10 != dwOption) && (OPT_D3DX11 != dwOption))
            {
                if(!*pValue)
                {
                    if((iArg + 1 >= argc))
                    {
                        PrintUsage();
                        return 1;
                    }

                    iArg++;
                    pValue = argv[iArg];
                }
            }


            switch(dwOption)
            {
            case OPT_WIDTH:
                if (swscanf_s(pValue, L"%u", &uWidth) != 1)
                {
                    wprintf( L"Invalid value specified with -w (%s)\n", pValue);
                    wprintf( L"\n");
                    PrintUsage();
                    return 1;
                }
                break;

            case OPT_HEIGHT:
                if (swscanf_s(pValue, L"%u", &uHeight) != 1)
                {
                    wprintf( L"Invalid value specified with -h (%s)\n", pValue);
                    printf("\n");
                    PrintUsage();
                    return 1;
                }
                break;

            case OPT_DEPTH:
                if (swscanf_s(pValue, L"%u", &uDepth) != 1)
                {
                    wprintf( L"Invalid value specified with -d (%s)\n", pValue);
                    wprintf( L"\n");
                    PrintUsage();
                    return 1;
                }
                break;

            case OPT_MIPLEVELS:
                if (swscanf_s(pValue, L"%u", &uMipLevels) != 1)
                {
                    wprintf( L"Invalid value specified with -m (%s)\n", pValue);
                    wprintf( L"\n");
                    PrintUsage();
                    return 1;
                }
                break;

            case OPT_FORMAT:
                Format = (DXGI_FORMAT) Lookup(pValue, g_pFormats);
                break;

            case OPT_FILTER:
                dwFilter = Lookup(pValue, g_pFilters);
                break;

            case OPT_MIPFILTER:
                dwMipFilter = Lookup(pValue, g_pFilters);
                break;

            case OPT_SRGBI:
                dwSRGB |= D3DX10_FILTER_SRGB_IN;
                break;

            case OPT_SRGBO:
                dwSRGB |= D3DX10_FILTER_SRGB_OUT;
                break;

            case OPT_SRGB:
                dwSRGB |= D3DX10_FILTER_SRGB;
                break;

            case OPT_PREFIX:
                wcscpy_s(szPrefix, MAX_PATH, pValue);
                break;

            case OPT_SUFFIX:
                wcscpy_s(szSuffix, MAX_PATH, pValue);
                break;

            case OPT_OUTPUTDIR:
                wcscpy_s(szOutputDir, MAX_PATH, pValue);
                break;

            case OPT_FILETYPE:
                FileType = (D3DX10_IMAGE_FILE_FORMAT) Lookup(pValue, g_pSaveFileTypes);
                break;

            case OPT_NOLOGO:
                break;

            case OPT_D3DX10:
                uAPI = 10;
                break;

            case OPT_D3DX11:
                uAPI = 11;
                break;
            }
        }
        else
        {         
            SConversion *pConv = new SConversion;
            if ( !pConv )
                return 1;

            wcscpy_s(pConv->szSrc, MAX_PATH, pArg);

            pConv->szDest[0] = 0;
            pConv->pNext = NULL;

            *ppConversion = pConv;
            ppConversion = &pConv->pNext;
        }
    }

    if(!pConversion)
    {
        PrintUsage();
        return 0;
    }

    if(~dwOptions & (1 << OPT_NOLOGO))
        PrintLogo();

    // Work out out filename prefix and suffix
    if(szOutputDir[0] && (L'\\' != szOutputDir[wcslen(szOutputDir) - 1]))
        wcscat_s( szOutputDir, MAX_PATH, L"\\" );

    if(szPrefix[0])
        wcscat_s(szOutputDir, MAX_PATH, szPrefix);

    wcscpy_s(szPrefix, MAX_PATH, szOutputDir);

    const WCHAR* fileTypeName = LookupFileType(FileType, g_pFileTypes);

    if (fileTypeName)
    {
        wcscat_s(szSuffix, MAX_PATH, L".");
        wcscat_s(szSuffix, MAX_PATH, fileTypeName);
    }
    else
    {
        wcscat_s(szSuffix, MAX_PATH, L".unknown");
    }

    if (FileType != D3DX10_IFF_DDS)
    {
        uMipLevels = 1;
        uDepth = 1;
    }

    // Create NULL device
    ID3D10Device* pDevice10 = NULL;
    ID3D10Resource* pTexture10 = NULL;

    ID3D11Device* pDevice11 = NULL;
    ID3D11DeviceContext* pContext11 = NULL;
    ID3D11Resource* pTexture11 = NULL;

    if ( FAILED(FindD3DExports(uAPI)) )
    {
        goto LError;
    }

    if ( uAPI == 11 )
    {
        if (FAILED(CreateDevice(&pDevice11, &pContext11)))
        {
            goto LError;
        }
    }
    else if ( uAPI == 10 )
    {
        if (FAILED(CreateDevice(&pDevice10)))
        {
            goto LError;
        }
    }
    else
    {
        if (FAILED(CreateDevice(&pDevice11, &pContext11)))
        {
            if (FAILED(CreateDevice(&pDevice10)))
            {
                goto LError;
            }
        }
    }

    // Convert images
    SConversion *pConv;

    for(pConv = pConversion; pConv; pConv = pConv->pNext)
    {
        // Read texture
        if(pConv != pConversion)
            wprintf( L"\n");

        wprintf( L"reading %s", pConv->szSrc);
        fflush(stdout);

        D3DX10_IMAGE_INFO Info;

        if ( g_pD3DX11GetImageInfoFromFile != NULL )
        {
            // D3DX10_IMAGE_INFO and D3DX11_IMAGE_INFO are identical
            if(FAILED(hr = g_pD3DX11GetImageInfoFromFile(pConv->szSrc, NULL, (D3DX11_IMAGE_INFO*)&Info, NULL)))
            {
                wprintf( L" FAILED (%x)\n", hr);
                continue;
            }
        }
        else if ( g_pD3DX10GetImageInfoFromFile != NULL )
        {
            if(FAILED(hr = g_pD3DX10GetImageInfoFromFile(pConv->szSrc, NULL, &Info, NULL)))
            {
                wprintf( L" L FAILED (%x)\n", hr);
                continue;
            }
        }
        else
        {
            goto LError;
        }

        PrintInfo(&Info);

        // Convert texture
        wprintf( L" as");
        fflush(stdout);

        D3DX10_IMAGE_LOAD_INFO loadInfo;
        memset( &loadInfo, 0, sizeof(loadInfo) );
        loadInfo.Width = uWidth;
        loadInfo.Height = uHeight;
        loadInfo.Depth = uDepth;
        loadInfo.FirstMipLevel = D3DX10_DEFAULT;
        loadInfo.MipLevels = uMipLevels;
        loadInfo.BindFlags = D3D10_BIND_SHADER_RESOURCE;
        loadInfo.Usage = D3D10_USAGE_DEFAULT;
        loadInfo.CpuAccessFlags = 0;
        loadInfo.Format = Format;
        loadInfo.Filter = dwFilter | dwSRGB;
        loadInfo.MipFilter = dwMipFilter;
        loadInfo.pSrcInfo = &Info;

        if ( g_pD3DX11CreateTextureFromFile != NULL )
        {
            // D3DX10_IMAGE_LOAD_INFO and D3DX11_IMAGE_LOAD_INFO are identical
            hr = g_pD3DX11CreateTextureFromFile(pDevice11, pConv->szSrc, (D3DX11_IMAGE_LOAD_INFO*)&loadInfo, NULL, &pTexture11, NULL);
            if(FAILED(hr))
            {
                wprintf( L" FAILED (%x)\n", hr);
                continue;
            }
        }
        else if ( g_pD3DX10CreateTextureFromFile != NULL )
        {
            hr = g_pD3DX10CreateTextureFromFile(pDevice10, pConv->szSrc, &loadInfo, NULL, &pTexture10, NULL);
            if(FAILED(hr))
            {
                wprintf( L" FAILED (%x)\n", hr);
                continue;
            }
        }
        else
        {
            goto LError;
        }

        if ( pTexture11 != NULL )
        {
            // D3D10_RESOURCE_DIMENSION and D3D11_RESOURCE_DIMENSION are identical
            switch( (D3D11_RESOURCE_DIMENSION)Info.ResourceDimension )
            {
            case D3D11_RESOURCE_DIMENSION_TEXTURE1D:
                D3D11_TEXTURE1D_DESC tex1D;
                ((ID3D11Texture1D*) pTexture11)->GetDesc(&tex1D);
    
                Info.Width     = (UINT)tex1D.Width;
                Info.Height    = 1;
                Info.Depth     = 1;
                Info.MipLevels = tex1D.MipLevels;
                Info.Format    = tex1D.Format;
                Info.ArraySize = tex1D.ArraySize;
                break;

            case D3D11_RESOURCE_DIMENSION_TEXTURE2D:
                D3D11_TEXTURE2D_DESC tex2D;
                ((ID3D11Texture2D*) pTexture11)->GetDesc(&tex2D);
    
                Info.Width     = (UINT)tex2D.Width;
                Info.Height    = (UINT)tex2D.Height;
                Info.Depth     = 1;
                Info.MipLevels = tex2D.MipLevels;
                Info.Format    = tex2D.Format;
                Info.ArraySize = tex2D.ArraySize;
                break;
    
            case D3D11_RESOURCE_DIMENSION_TEXTURE3D:
                D3D11_TEXTURE3D_DESC tex3D;
                ((ID3D11Texture3D*) pTexture11)->GetDesc(&tex3D);
    
                Info.Width     = (UINT)tex3D.Width;
                Info.Height    = (UINT)tex3D.Height;
                Info.Depth     = (UINT)tex3D.Depth;
                Info.MipLevels = tex3D.Format;
                Info.Format    = tex3D.Format;
                break;
            }
        }
        else if ( pTexture10 != NULL )
        {
            switch(Info.ResourceDimension)
            {
            case D3D10_RESOURCE_DIMENSION_TEXTURE1D:
                D3D10_TEXTURE1D_DESC tex1D;
                ((ID3D10Texture1D*) pTexture11)->GetDesc(&tex1D);
    
                Info.Width     = (UINT)tex1D.Width;
                Info.Height    = 1;
                Info.Depth     = 1;
                Info.MipLevels = tex1D.MipLevels;
                Info.Format    = tex1D.Format;
                Info.ArraySize = tex1D.ArraySize;
                break;

            case D3D10_RESOURCE_DIMENSION_TEXTURE2D:
                D3D10_TEXTURE2D_DESC tex2D;
                ((ID3D10Texture2D*) pTexture10)->GetDesc(&tex2D);
    
                Info.Width     = (UINT)tex2D.Width;
                Info.Height    = (UINT)tex2D.Height;
                Info.Depth     = 1;
                Info.MipLevels = tex2D.MipLevels;
                Info.Format    = tex2D.Format;
                Info.ArraySize = tex2D.ArraySize;
                break;
    
            case D3D10_RESOURCE_DIMENSION_TEXTURE3D:
                D3D10_TEXTURE3D_DESC tex3D;
                ((ID3D10Texture3D*) pTexture10)->GetDesc(&tex3D);
    
                Info.Width     = (UINT)tex3D.Width;
                Info.Height    = (UINT)tex3D.Height;
                Info.Depth     = (UINT)tex3D.Depth;
                Info.MipLevels = tex3D.Format;
                Info.Format    = tex3D.Format;
                break;
            }
        }
        else
            goto LError;

        PrintInfo(&Info);
        wprintf( L"\n");

        // Figure out dest filename
        WCHAR *pchSlash, *pchDot;

        wcscpy_s(pConv->szDest, MAX_PATH, szPrefix);

        pchSlash = wcsrchr(pConv->szSrc, L'\\');
        if(pchSlash != 0)
            wcscat_s(pConv->szDest, MAX_PATH, pchSlash + 1);
        else
            wcscat_s(pConv->szDest, MAX_PATH, pConv->szSrc);

        pchSlash = wcsrchr(pConv->szDest, '\\');
        pchDot = wcsrchr(pConv->szDest, '.');

        if(pchDot > pchSlash)
            *pchDot = 0;

        wcscat_s(pConv->szDest, MAX_PATH, szSuffix);

        // Write texture
        wprintf( L"writing %s", pConv->szDest);
        fflush(stdout);

        if ( g_pD3DX11SaveTextureToFile != NULL )
        {
            // D3DX10_IMAGE_FILE_FORMAT and D3DX11_IMAGE_FILE_FORMAT are identical
            hr = g_pD3DX11SaveTextureToFile( pContext11, pTexture11, (D3DX11_IMAGE_FILE_FORMAT)FileType, pConv->szDest );
        }
        else if ( g_pD3DX10SaveTextureToFile != NULL )
        {
            hr = g_pD3DX10SaveTextureToFile( pTexture10, FileType, pConv->szDest );
        }
        else
            goto LError;

        SAFE_RELEASE(pTexture10);
        SAFE_RELEASE(pTexture11);

        if(FAILED(hr))
        {
            wprintf( L" FAILED (%x)\n", hr);
            continue;
        }

        if ( g_pD3DX11GetImageInfoFromFile != NULL )
        {
            // D3DX10_IMAGE_INFO and D3DX11_IMAGE_INFO are identical
            if(FAILED(hr = g_pD3DX11GetImageInfoFromFile(pConv->szDest, NULL, (D3DX11_IMAGE_INFO*)&Info, NULL)))
            {
                wprintf( L" FAILED (%x)\n", hr);
                continue;
            }
        }
        else if ( g_pD3DX10GetImageInfoFromFile != NULL )
        {
            if(FAILED(hr = g_pD3DX10GetImageInfoFromFile(pConv->szDest, NULL, &Info, NULL)))
            {
                wprintf( L" FAILED (%x)\n", hr);
                continue;
            }
        }
        else
        {
            goto LError;
        }

        PrintInfo(&Info);
        wprintf( L"\n");
    }


    nReturn = 0;
    goto LDone;

LError:
    nReturn = 1;

LDone:
    SAFE_RELEASE(pTexture11);
    SAFE_RELEASE(pContext11);
    SAFE_RELEASE(pDevice11);

    SAFE_RELEASE(pTexture10);
    SAFE_RELEASE(pDevice10);

    while(pConversion)
    {
        pConv = pConversion;
        pConversion = pConversion->pNext;
        delete pConv;
    }

    return nReturn;
}
